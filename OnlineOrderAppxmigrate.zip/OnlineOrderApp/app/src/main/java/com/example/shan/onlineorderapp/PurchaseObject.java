package com.example.shan.onlineorderapp;


/**
 * Created by Shan on 21-Apr-16.
 */
public class PurchaseObject {
    public int code;
    public String productname;
    public int User_Qty;
    public String productdescription;
    public int Total_price;



}
