package com.example.shan.onlineorderapp;

/**
 * Created by Shan on 14-Apr-16.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://192.168.43.61/oos/DB_Functions.php";

    // Server user register url
    public static String URL_REGISTER = "http://192.168.43.61/oos/register.php";
}
